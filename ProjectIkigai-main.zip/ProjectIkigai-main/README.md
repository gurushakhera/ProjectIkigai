<h1>Project Ikigai</h1>
A one-stop solution for all mental health related issues.
